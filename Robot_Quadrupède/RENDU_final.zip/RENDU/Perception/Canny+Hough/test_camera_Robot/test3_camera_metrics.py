#!/usr/bin/env python3
import rospy
import numpy as np
import cv2
from sensor_msgs.msg import Image, CameraInfo
from std_msgs.msg import Bool, Int32
from cv_bridge import CvBridge
from collections import deque
import message_filters

# ─────────────────────────────────────────────
# VARIABLES GLOBALES
# ─────────────────────────────────────────────
bridge = CvBridge()              # Passerelle pour convertir les images ROS en matrices OpenCV (numpy)
fx = fy = cx = cy = None         # Paramètres de la matrice intrinsèque de la caméra (remplis via camera_info)
clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8)) # Égalisation locale pour harmoniser les contrastes
frame_count = 0                  # Compteur incrémentiel du nombre de frames synchronisées reçues
pub_escalier = None              # Publisher ROS pour l'état d'obstacle (True/False)
pub_nb_marches = None            # Publisher ROS pour remonter le nombre exact de marches physiques valides
derniere_detection = False   # Mémoire de l'état précédent pour filtrer et ne pas saturer les logs du terminal

def callback_info(msg):
    """
    Récupère la matrice de projection intrinsèque K de la caméra.
    Nécessaire une seule fois au démarrage pour l'étape de rétroprojection 2D -> 3D.
    """
    global fx, fy, cx, cy
    if fx is None:
        # K est un tableau plat de 9 éléments : [fx, 0, cx, 0, fy, cy, 0, 0, 1]
        fx, fy, cx, cy = msg.K[0], msg.K[4], msg.K[2], msg.K[5]

def pixel_to_3d(px, py, depth_m):
    """
    Rétroprojette un point 2D de l'image (px, py) associé à sa profondeur (depth_m)
    dans le repère orthonormé 3D de la caméra (X, Y, Z) en mètres.
    """
    if fx is None or fx == 0: return np.array([0, 0, 0])
    x = (px - cx) * depth_m / fx
    y = (py - cy) * depth_m / fy
    return np.array([x, y, depth_m])

def extraire_niveaux(lines, depth_img, h, w):
    """
    Filtre, segmente et regroupe géométriquement les lignes horizontales (nez de marches) :
    1. Analyse de l'horizontalité, de la longueur minimale et de la ROI verticale.
    2. Extraction directe de la profondeur brute de l'image depth (en mm).
    3. Fusion locale des segments superposés ou proches appartenant à la même marche.
    """
    # Zone d'intérêt (ROI) verticale exprimée en ratio de la hauteur totale de l'image
    roi_top, roi_bottom = int(h * 0.25), int(h * 0.90)
    candidats = []
    if lines is None: return candidats
    
    for line in lines:
        x1, y1, x2, y2 = line[0]
        # 1. Filtre d'horizontalité stricte (écart vertical max toléré entre les extrémités)
        if abs(y1 - y2) > 12: continue
        # 2. Filtre de longueur pour écarter le bruit de texture du sol
        longueur = abs(x2 - x1)
        if longueur < 50: continue
        # 3. Validation de l'appartenance à la ROI verticale
        y_moy = (y1 + y2) // 2
        if not (roi_top <= y_moy <= roi_bottom): continue
        
        mid_x, mid_y = (x1 + x2) // 2, y_moy
        # Anti-crash : vérification des limites physiques de la matrice d'image
        if mid_y >= depth_img.shape[0] or mid_x >= depth_img.shape[1]: continue
        
        # 4. Lecture de la profondeur brute (uint16) et conversion en mètres
        d_mm = depth_img[mid_y, mid_x]
        dist = d_mm * 0.001
        
        # 5. Filtrage par rapport à la plage opérationnelle du capteur (0.4m à 2.5m)
        if 0.40 < dist < 2.50:
            candidats.append({
                "x1": x1, "y1": y1, "x2": x2, "y2": y2, "y_moy": y_moy,
                "mid_x": mid_x, "mid_y": mid_y, "depth_m": dist,
                "point3d": pixel_to_3d(mid_x, mid_y, dist), "longueur": longueur
            })
            
    # Tri spatial des lignes du haut vers le bas de la scène visuelle
    candidats.sort(key=lambda c: c["y_moy"])
    
    # Algorithme de clustering spatial (fusion) pour les lignes proches (écart < 35 pixels)
    groupes = []
    for c in candidats:
        merge = False
        for g in groupes:
            if abs(g["y_moy"] - c["y_moy"]) < 35:
                # On conserve les données géométriques de la ligne la plus longue (plus stable)
                if c["longueur"] > g["longueur"]: g.update(c)
                merge = True
                break
        if not merge: groupes.append(dict(c))
    return groupes

def calculer_metriques(niveaux):
    """
    Calcule l'écart spatial 3D réel (hauteur et profondeur en cm) entre deux lignes successives.
    Vérifie la conformité de chaque marche selon les spécifications architecturales standards.
    """
    if len(niveaux) < 2: return 0, []
    marches = []
    for i in range(len(niveaux) - 1):
        p_bas, p_haut = niveaux[i]["point3d"], niveaux[i+1]["point3d"]
        # Différence sur l'axe vertical réel Y
        h_cm = abs(p_haut[1] - p_bas[1]) * 100
        # Différence sur l'axe de profondeur réel Z
        p_cm = abs(p_haut[2] - p_bas[2]) * 100
        
        # Validation d'une marche selon sa hauteur (5-35cm) et son giron/profondeur (10-60cm)
        valide = (5.0 <= h_cm <= 35.0 and 10.0 <= p_cm <= 60.0)
        marches.append({
            "index": i+1,
            "hauteur_cm": round(h_cm, 1),
            "profondeur_cm": round(p_cm, 1),
            "dist_cam_m": round(niveaux[i]["depth_m"], 2),
            "valide": valide
        })
    return sum(1 for m in marches if m["valide"]), marches

def afficher_terminal(nb_valides, marches, frame_count):
    """
    Formate et affiche un rapport complet des métriques de la frame courante dans la console.
    """
    print("\n" + "═" * 55)
    print(f"  Frame {frame_count}  |  {nb_valides} marche(s) détectée(s)")
    print("═" * 55)
    for m in marches:
        tag = "✓" if m["valide"] else "✗"
        print(f"  Marche {m['index']} {tag}  "
              f"H:{m['hauteur_cm']:>5.1f}cm  "
              f"P:{m['profondeur_cm']:>5.1f}cm  "
              f"Dist:{m['dist_cam_m']:.2f}m")
    print("─" * 55)
    
"""def afficher_terminal(nb_valides, marches, frame_count):
    print("\n" + "═" * 55)
    print(f"  Frame {frame_count}  |  {nb_valides} marche(s) détectée(s)")
    print("═" * 55)
    for m in marches:
        tag = "✓" if m["valide"] else "✗"
        print(f"  Marche {m['index']} {tag}  Dist:{m['dist_cam_m']:.2f}m")
    print("─" * 55)"""
    
def callback(color_msg, depth_msg):
    """
    Callback principal déclenché lors de la réception de paires d'images synchronisées.
    Gère le pré-traitement d'image, l'extraction de primitives, la logique métier et la publication ROS.
    """
    global fx, frame_count, derniere_detection

    if fx is None: return

    frame_count += 1
    # Conversion des messages d'images ROS vers OpenCV (BGR pour la couleur, 16-bit non signé pour la profondeur)
    frame     = bridge.imgmsg_to_cv2(color_msg, "bgr8")
    depth_raw = bridge.imgmsg_to_cv2(depth_msg, "16UC1")
    h, w = frame.shape[:2]

    # Redimensionnement préventif si les dimensions des flux couleur et profondeur diffèrent
    if depth_raw.shape[0] != h or depth_raw.shape[1] != w:
        depth_img = cv2.resize(depth_raw, (w, h), interpolation=cv2.INTER_NEAREST)
    else:
        depth_img = depth_raw

    # ── Pipeline de Vision par Ordinateur (2D) ────────────────
    gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    gray  = clahe.apply(gray)                     # Normalisation locale de la luminosité
    blur  = cv2.GaussianBlur(gray, (5, 5), 0)     # Filtrage gaussien anti-bruit
    edges = cv2.Canny(blur, 60, 160)              # Extraction des contours par filtre de Canny

    # Détection des segments de droites via la transformée de Hough probabiliste
    lines   = cv2.HoughLinesP(edges, 1, np.pi/180, 45, minLineLength=55, maxLineGap=35)
    niveaux = extraire_niveaux(lines, depth_img, h, w)
    nb_valides, marches = calculer_metriques(niveaux)

    # L'obstacle escalier est validé à partir d'au moins 2 marches physiques conformes
    escalier_detecte = nb_valides >= 2

    # ── Métriques terminal (toutes les 30 frames ou changement d'état) ──
    if frame_count % 30 == 0 or (escalier_detecte != derniere_detection):
        afficher_terminal(nb_valides, marches, frame_count)

    # ── Publication des Topics ROS ──
    pub_escalier.publish(Bool(data=escalier_detecte))
    pub_nb_marches.publish(Int32(data=nb_valides))

    # Gestion des logs de notification ROS lors du basculement d'état d'environnement
    if escalier_detecte != derniere_detection:
        if escalier_detecte:
            rospy.logwarn(f" ESCALIER DÉTECTÉ — {nb_valides} marche(s) !")
        else:
            rospy.loginfo("✓  Voie dégagée.")
        derniere_detection = escalier_detecte

    # ── Rendu de la superposition Graphique (Debug Visual) ──
    debug_frame = frame.copy()
    for niv in niveaux:
        # Dessin des lignes horizontales retenues
        cv2.line(debug_frame, (niv["x1"], niv["y1"]), (niv["x2"], niv["y2"]), (0, 255, 0), 2)
        # Point central de sondage télémétrique
        cv2.circle(debug_frame, (niv["mid_x"], niv["mid_y"]), 4, (255, 0, 0), -1)
        # Affichage textuel de la distance de la ligne en mètres
        cv2.putText(debug_frame, f"{niv['depth_m']:.2f}m",
                    (niv["mid_x"]+5, niv["mid_y"]-5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 0), 1)

    # Boîtier d'informations d'état (OSD) en haut à gauche
    couleur = (0, 255, 0) if escalier_detecte else (0, 100, 255)
    cv2.rectangle(debug_frame, (10, 10), (420, 60), (0, 0, 0), -1)
    cv2.putText(debug_frame, f"Marches : {nb_valides}  {'ESCALIER !' if escalier_detecte else 'RAS'}",
                (18, 45), cv2.FONT_HERSHEY_SIMPLEX, 0.8, couleur, 2)

    # Affichage de la fenêtre graphique locale
    cv2.imshow("Lite3 - Detection Escalier", debug_frame)
    cv2.waitKey(1)

if __name__ == '__main__':
    # Initialisation du nœud de calcul ROS
    rospy.init_node('detection_escalier', anonymous=True)

    # Instanciation des Publishers ROS (Sorties)
    pub_escalier   = rospy.Publisher('/escalier_detecte',   Bool,  queue_size=1)
    pub_nb_marches = rospy.Publisher('/escalier_nb_marches', Int32, queue_size=1)

    # Configuration des Subscribers (Entrées)
    rospy.Subscriber('/camera/color/camera_info', CameraInfo, callback_info)
    color_sub = message_filters.Subscriber('/camera/color/image_raw', Image)
    depth_sub = message_filters.Subscriber('/camera/depth/image_rect_raw', Image)
    
    # Synchronisation temporelle approximative (tolérance de 0.1s max) pour appairer RGB et Depth
    ts = message_filters.ApproximateTimeSynchronizer([color_sub, depth_sub], 10, 0.1)
    ts.registerCallback(callback)

    rospy.loginfo("Nœud démarré — topics publiés :")
    rospy.loginfo("  /escalier_detecte    (Bool)")
    rospy.loginfo("  /escalier_nb_marches (Int32)")
    
    # Boucle d'attente bloquante gérant l'appel asynchrone des callbacks
    rospy.spin()
    
    # Nettoyage des fenêtres graphiques X11 lors de la destruction du nœud (Ctrl+C)
    cv2.destroyAllWindows()