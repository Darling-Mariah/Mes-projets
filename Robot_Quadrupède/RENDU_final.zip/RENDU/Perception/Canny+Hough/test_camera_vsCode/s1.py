import numpy as np
import cv2
import pyrealsense2 as rs
from collections import deque
import time

# ─────────────────────────────────────────────
# PARAMÈTRES AJUSTABLES
# ─────────────────────────────────────────────
MIN_MARCHES          = 2       # Nombre minimum de marches pour valider un escalier
MAX_MARCHES          = 20      # Seuil max pour éliminer les faux positifs
DIST_MIN_M           = 0.40    # Distance caméra → escalier (min, en mètres)
DIST_MAX_M           = 2.50    # Distance caméra → escalier (max, en mètres)
HAUTEUR_MIN_CM       = 5.0     # Hauteur minimale d'une vraie marche (cm)
HAUTEUR_MAX_CM       = 35.0    # Hauteur maximale d'une vraie marche (cm)
PROFONDEUR_MIN_CM    = 10.0    # Profondeur minimale d'une vraie marche (cm)
PROFONDEUR_MAX_CM    = 60.0    # Profondeur maximale d'une vraie marche (cm)
SEUIL_GROUPEMENT_PX  = 35      # Pixels pour fusionner des lignes voisines
FRAMES_VALIDATION    = 3       # Détections consécutives pour valider + arrêter
HISTORY_SIZE         = 10      # Fenêtre glissante pour la stabilité du comptage

# ─────────────────────────────────────────────
# INITIALISATION REALSENSE
# ─────────────────────────────────────────────
# Configuration des flux vidéo et de profondeur (640x480 à 30 FPS)
pipeline = rs.pipeline()
config   = rs.config()
config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16,  30)

# Démarrage du capteur et alignement spatial de la profondeur sur l'image couleur
profile = pipeline.start(config)
align   = rs.align(rs.stream.color)

# Récupération des paramètres intrinsèques de la caméra pour la rétroprojection 3D
intr = profile.get_stream(rs.stream.color).as_video_stream_profile().get_intrinsics()
fx, fy = intr.fx, intr.fy
cx, cy = intr.ppx, intr.ppy

# Initialisation de l'égalisation locale d'histogramme (CLAHE) pour améliorer le contraste
clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))

# ─────────────────────────────────────────────
# ÉTAT / VARIABLES DE SUIVI
# ─────────────────────────────────────────────
historique_comptage  = deque(maxlen=HISTORY_SIZE) # Stocke l'historique des détections pour filtrage temporel
series_validees      = 0          # Compteur de frames consécutives valides
resultats_finaux     = []         # Stockage des données physiques des escaliers détectés
frame_count          = 0          # Compteur total de frames traitées
faux_positifs        = 0          # Compteur d'alertes rejetées par les critères géométriques
vrais_positifs       = 0          # Compteur de détections confirmées
total_frames_escalier = 0

# ─────────────────────────────────────────────
# FONCTIONS UTILITAIRES
# ─────────────────────────────────────────────

def pixel_to_3d(px, py, depth_m):
    """
    Convertit les coordonnées d'un pixel (px, py) et sa profondeur (depth_m)
    en coordonnées géométriques 3D réelles (X, Y, Z) exprimées en mètres.
    """
    x = (px - cx) * depth_m / fx
    y = (py - cy) * depth_m / fy
    z = depth_m
    return np.array([x, y, z])


def get_depth_median(depth_frame, px, py, radius=3):
    """
    Calcule la profondeur médiane autour d'un pixel cible sur un voisinage (radius).
    Permet de filtrer le bruit de mesure et les valeurs aberrantes (0.0 / trous).
    """
    h, w = 480, 640
    samples = []
    for dy in range(-radius, radius + 1):
        for dx in range(-radius, radius + 1):
            nx, ny = px + dx, py + dy
            if 0 <= nx < w and 0 <= ny < h:
                d = depth_frame.get_distance(nx, ny)
                if d > 0: # Élimination des pixels invalides ou non mesurés
                    samples.append(d)
    return float(np.median(samples)) if samples else 0.0


def extraire_niveaux(lines, depth_frame, frame_h):
    """
    Analyse les segments de lignes détectés par Hough :
    1. Filtre selon l'horizontalité, la longueur et la zone d'intérêt (ROI).
    2. Récupère la profondeur 3D associée à chaque segment.
    3. Fusionne (groupe) les lignes qui appartiennent au même nez de marche.
    Retourne une liste triée du haut vers le bas de l'image.
    """
    # Définition de la ROI verticale pour exclure le plafond et le sol immédiat
    roi_top    = int(frame_h * 0.25)
    roi_bottom = int(frame_h * 0.90)

    candidats = []

    if lines is None:
        return candidats

    for line in lines:
        x1, y1, x2, y2 = line[0]

        # 1. Filtre d'horizontalité stricte (pente très faible tolérée)
        if abs(y1 - y2) > 12:
            continue

        # 2. Filtre de longueur minimale pour écarter le bruit de texture
        longueur = abs(x2 - x1)
        if longueur < 50:
            continue

        # 3. Validation de la position dans la zone d'intérêt (ROI)
        y_moy = (y1 + y2) // 2
        if not (roi_top <= y_moy <= roi_bottom):
            continue

        # 4. Extraction de la profondeur au centre de la ligne détectée
        mid_x = (x1 + x2) // 2
        mid_y = y_moy
        dist = get_depth_median(depth_frame, mid_x, mid_y, radius=4)

        # 5. Validation par rapport à la plage de distance d'action de la caméra
        if not (DIST_MIN_M < dist < DIST_MAX_M):
            continue

        # Agrégation des propriétés géométriques valides du segment
        candidats.append({
            "x1": x1, "y1": y1, "x2": x2, "y2": y2,
            "y_moy": y_moy, "mid_x": mid_x, "mid_y": mid_y,
            "depth_m": dist,
            "point3d": pixel_to_3d(mid_x, mid_y, dist),
            "longueur": longueur,
        })

    # Tri des lignes par coordonnée Y croissante (du haut vers le bas de l'écran)
    candidats.sort(key=lambda c: c["y_moy"])

    # Algorithme de fusion : regroupe les segments trop proches verticalement
    groupes = []
    for c in candidats:
        merge = False
        for g in groupes:
            if abs(g["y_moy"] - c["y_moy"]) < SEUIL_GROUPEMENT_PX:
                # En cas de superposition, on conserve la ligne la plus longue et robuste
                if c["longueur"] > g["longueur"]:
                    g.update(c)
                merge = True
                break
        if not merge:
            groupes.append(dict(c))

    return groupes


def calculer_metriques(niveaux):
    """
    Analyse l'écart spatial entre deux nez de marches consécutifs.
    Calcule les dimensions réelles (hauteur et profondeur en cm) de chaque marche 
    et vérifie si elles respectent les normes physiques configurées.
    """
    if len(niveaux) < 2:
        return 0, []

    marches = []
    for i in range(len(niveaux) - 1):
        p_bas  = niveaux[i]["point3d"]    # Nez de la marche inférieure (proche en pixels)
        p_haut = niveaux[i + 1]["point3d"] # Nez de la marche supérieure (plus loin)

        # Hauteur correspond à l'écart absolu sur l'axe Y vertical réel
        hauteur_cm   = abs(p_haut[1] - p_bas[1]) * 100
        # Profondeur (giron) correspond à l'écart absolu sur l'axe Z de profondeur
        profondeur_cm = abs(p_haut[2] - p_bas[2]) * 100

        # Vérification des tolérances physiques (filtre géométrique strict)
        valide = (HAUTEUR_MIN_CM   <= hauteur_cm   <= HAUTEUR_MAX_CM and
                  PROFONDEUR_MIN_CM <= profondeur_cm <= PROFONDEUR_MAX_CM)

        marches.append({
            "index":         i + 1,
            "hauteur_cm":    round(hauteur_cm,    1),
            "profondeur_cm": round(profondeur_cm, 1),
            "dist_cam_m":    round(niveaux[i]["depth_m"], 2),
            "valide":        valide,
        })

    # Décompte total des marches répondant aux critères physiques d'un vrai escalier
    nb_valides = sum(1 for m in marches if m["valide"])
    return nb_valides, marches


def afficher_metriques_terminal(detection_id, nb_marches, marches, frame_id):
    """
    Génère un affichage structuré et formaté dans la console
    pour suivre en temps réel les dimensions géométriques estimées.
    """
    print("\n" + "═" * 60)
    print(f"   DÉTECTION #{detection_id}  |  Frame {frame_id}  |  {nb_marches} marche(s) valide(s)")
    print("═" * 60)
    for m in marches:
        tag = "✓" if m["valide"] else "✗ (hors norme)"
        print(f"  Marche {m['index']:>2}  {tag}")
        print(f"           Hauteur    : {m['hauteur_cm']:>6.1f} cm")
        print(f"           Profondeur : {m['profondeur_cm']:>6.1f} cm")
        print(f"           Dist caméra: {m['dist_cam_m']:>6.2f} m")
    print("─" * 60)


def rapport_final(resultats, total_frames, faux_pos, vrais_pos):
    """
    Affiche une synthèse statistique globale lors de la fermeture du programme :
    nombre de frames analysées, taux de faux positifs, hauteurs/profondeurs moyennes.
    """
    print("\n\n" + "█" * 60)
    print("  RAPPORT FINAL — FIN DE DÉTECTION")
    print("█" * 60)
    print(f"  Frames analysées       : {total_frames}")
    print(f"  Détections validées    : {len(resultats)}")
    print(f"  Vrais positifs (scènes): {vrais_pos}")
    print(f"  Faux positifs écartés  : {faux_pos}")
    if resultats:
        toutes_hauteurs    = [m["hauteur_cm"]    for r in resultats for m in r["marches"] if m["valide"]]
        toutes_profondeurs = [m["profondeur_cm"] for r in resultats for m in r["marches"] if m["valide"]]
        if toutes_hauteurs:
            print(f"\n  ── Statistiques sur les marches valides ──")
            print(f"  Hauteur moyenne    : {np.mean(toutes_hauteurs):.1f} cm  "
                  f"(min {np.min(toutes_hauteurs):.1f} / max {np.max(toutes_hauteurs):.1f})")
            print(f"  Profondeur moyenne : {np.mean(toutes_profondeurs):.1f} cm  "
                  f"(min {np.min(toutes_profondeurs):.1f} / max {np.max(toutes_profondeurs):.1f})")
    print("█" * 60 + "\n")


# ─────────────────────────────────────────────
# BOUCLE PRINCIPALE
# ─────────────────────────────────────────────
print("Démarrage de la détection d'escalier. Appuyer sur 'q' pour quitter manuellement.")
print(f"Arrêt automatique après {FRAMES_VALIDATION} détections consécutives cohérentes.\n")

try:
    while True:
        # Capturer, synchroniser et aligner les flux couleur et profondeur
        frames         = pipeline.wait_for_frames()
        aligned_frames = align.process(frames)
        depth_frame    = aligned_frames.get_depth_frame()
        color_frame    = aligned_frames.get_color_frame()

        if not depth_frame or not color_frame:
            continue

        frame_count += 1
        frame = np.asanyarray(color_frame.get_data())
        h, w  = frame.shape[:2]

        # ── Pré-traitement image ──────────────────────────────────
        gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray  = clahe.apply(gray)                      # Amélioration dynamique locale du contraste
        blur  = cv2.GaussianBlur(gray, (5, 5), 0)      # Lissage pour atténuer le bruit haute fréquence
        edges = cv2.Canny(blur, 60, 160)               # Détection des contours (gradients d'intensité)

        # ── Détection de segments ─────────────────────────────────
        # Algorithme de Hough Probabiliste pour extraire les segments de droite
        lines = cv2.HoughLinesP(
            edges, 1, np.pi / 180,
            threshold=45, minLineLength=55, maxLineGap=35
        )

        # ── Extraction des niveaux 3D ─────────────────────────────
        # Filtrage, calcul de profondeur et fusion des segments
        niveaux = extraire_niveaux(lines, depth_frame, h)

        # ── Calcul des métriques physiques ────────────────────────
        # Extraction des dimensions réelles des marches trouvées
        nb_valides, marches = calculer_metriques(niveaux)

        # ── Filtrage anti-faux positifs ───────────────────────────
        # Validation immédiate : le nombre de marches valides est-il dans la fourchette ?
        escalier_detecte = (MIN_MARCHES <= nb_valides <= MAX_MARCHES)
        historique_comptage.append(nb_valides if escalier_detecte else 0)

        # Cohérence temporelle : Analyse de la fenêtre glissante pour s'assurer
        # que le nombre de marches détecté est stable (médiane persistante)
        comptage_dominant = 0
        if len(historique_comptage) >= 4:
            vals = list(historique_comptage)[-6:]
            if vals:
                median_val = int(np.median(vals))
                proches = sum(1 for v in vals if abs(v - median_val) <= 1)
                if proches >= int(len(vals) * 0.6):
                    comptage_dominant = median_val

        # ── Dessin des lignes détectées ───────────────────────────
        debug_frame = frame.copy()
        for niv in niveaux:
            # Vert si l'escalier global est validé, Orange si la ligne est isolée/suspecte
            couleur = (0, 255, 0) if escalier_detecte else (0, 165, 255)
            cv2.line(debug_frame, (niv["x1"], niv["y1"]),
                     (niv["x2"], niv["y2"]), couleur, 2)
            cv2.circle(debug_frame, (niv["mid_x"], niv["mid_y"]), 4, (255, 0, 0), -1)
            cv2.putText(debug_frame,
                        f"{niv['depth_m']:.2f}m",
                        (niv["mid_x"] + 5, niv["mid_y"] - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 0), 1)

        # ── Affichage OSD (Inscrustation Écran) ────────────────────
        couleur_osd = (0, 255, 0) if escalier_detecte else (0, 100, 255)
        cv2.rectangle(debug_frame, (10, 10), (460, 100), (0, 0, 0), -1)
        cv2.putText(debug_frame,
                    f"Marches valides : {nb_valides}  |  Stable : {comptage_dominant}",
                    (18, 45), cv2.FONT_HERSHEY_SIMPLEX, 0.75, couleur_osd, 2)
        cv2.putText(debug_frame,
                    f"Series : {series_validees}/{FRAMES_VALIDATION}   Frame : {frame_count}",
                    (18, 85), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (200, 200, 200), 1)

        # ── Logique de validation ─────────────────────────────────
        # Si la frame actuelle et l'historique temporel concordent
        if escalier_detecte and comptage_dominant >= MIN_MARCHES:
            series_validees += 1
            total_frames_escalier += 1
            vrais_positifs += 1

            afficher_metriques_terminal(series_validees, nb_valides, marches, frame_count)
            resultats_finaux.append({"detection": series_validees,
                                     "frame": frame_count,
                                     "nb_marches": nb_valides,
                                     "marches": marches})

            # Si le nombre requis de détections consécutives stables est atteint, on arrête
            if series_validees >= FRAMES_VALIDATION:
                cv2.imshow("RealSense - Détection Escalier", debug_frame)
                cv2.waitKey(500) # Petite pause visuelle finale avant la rupture
                break
        else:
            # Comptabilisation des structures ressemblant à un escalier mais rejetées après coup
            if escalier_detecte is False and nb_valides > 0:
                faux_positifs += 1
            series_validees = 0  # Réinitialisation stricte du compteur de série si rupture de cohérence

        # Rendu de la fenêtre d'affichage OpenCV
        cv2.imshow("RealSense - Détection Escalier", debug_frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            print("\n[INFO] Arrêt manuel par l'utilisateur.")
            break

finally:
    # Libération propre des ressources matérielles de la caméra et fermeture des fenêtres graphiques
    pipeline.stop()
    cv2.destroyAllWindows()
    # Affichage du bilan complet des données mesurées
    rapport_final(resultats_finaux, frame_count, faux_positifs, vrais_positifs)