import csv
import os
import matplotlib
# Configuration de Matplotlib pour générer des fichiers graphiques en arrière-plan sans interface requise
matplotlib.use("Agg") 
import matplotlib.pyplot as plt

class StairChecker:
    def __init__(self, output_dir="./resultats_detection"):
        """
        Initialise l'analyseur avec le dossier de sauvegarde et les dimensions
        standards de référence (cibles idéales) pour le calcul des écarts.
        """
        self.output_dir = output_dir
        # Valeurs idéales cibles converties en mètres
        self.target_profondeur = 0.25  # 25 cm -> giron cible
        self.target_hauteur = 0.19     # 19 cm -> hauteur cible
        self.samples = []              # Liste pour accumuler les couples de mesures

    def ajouter_mesure(self, prof_cm, haut_cm):
        """
        Reçoit une mesure brute issue des capteurs (en cm), la convertit en mètres,
        puis l'ajoute à la base de données interne.
        """
        # Conversion cm en mètres pour le script
        self.samples.append({"p": prof_cm / 100.0, "h": haut_cm / 100.0})

    def generer_rapport(self):
        """
        Génère le dossier de sortie, calcule les statistiques descriptives complètes,
        sauvegarde les résultats sous format CSV et produit les histogrammes de distribution.
        """
        if not self.samples:
            print("Aucune donnée valide à analyser.")
            return

        # Création du dossier d'exportation s'il n'existe pas déjà
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Extraction des séries distinctes pour la profondeur et la hauteur
        profs = [s["p"] for s in self.samples]
        hauts = [s["h"] for s in self.samples]

        # Calcul des métriques statistiques pour chaque dimension géométrique
        stats_p = self.calculer_stats("Profondeur", profs, self.target_profondeur)
        stats_h = self.calculer_stats("Hauteur", hauts, self.target_hauteur)

        # Sauvegarde des structures statistiques calculées dans un fichier CSV
        with open(os.path.join(self.output_dir, "analyse_capteur.csv"), "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=stats_p.keys())
            writer.writeheader()
            writer.writerows([stats_p, stats_h])

        # Génération et enregistrement des tracés graphiques (histogrammes)
        self.tracer_hist(profs, self.target_profondeur, "Profondeur (m)", "hist_profondeur.png")
        self.tracer_hist(hauts, self.target_hauteur, "Hauteur (m)", "hist_hauteur.png")
        
        print(f"--- ANALYSE TERMINÉE ---")
        print(f"Données traitées : {len(self.samples)} marches")
        print(f"Résultats dans : {self.output_dir}")

    def calculer_stats(self, nom, valeurs, cible):
        """
        Calcule la moyenne, l'erreur absolue moyenne et le biais systématique (m)
        d'une liste d'échantillons vis-à-vis d'une valeur théorique idéale.
        """
        moyenne = sum(valeurs) / len(valeurs)
        return {
            "Dimension": nom,
            "Nb_Mesures": len(valeurs),
            "Cible_Ideale": cible,
            "Moyenne_Observee": round(moyenne, 4),
            # Erreur absolue moyenne : mesure globale de la dispersion/précision de la mesure
            "Erreur_Moyenne_Abs": round(sum(abs(v - cible) for v in valeurs) / len(valeurs), 4),
            # Biais : détermine si le capteur a tendance à sous-estimer (-) ou surestimer (+) la réalité
            "Biais (m)": round(moyenne - cible, 4)
        }

    def tracer_hist(self, valeurs, cible, label, nom_fichier):
        """
        Génère un histogramme de la distribution des mesures observées,
        ajoute une ligne verticale de référence pour la cible et exporte l'image.
        """
        plt.figure(figsize=(8, 5))
        # Création de l'histogramme découpé en 8 intervalles discrets
        plt.hist(valeurs, bins=8, edgecolor="black", color="lightgreen", alpha=0.7)
        # Ajout de la ligne verticale rouge pointillée matérialisant la cible théorique
        plt.axvline(cible, color="red", linestyle="--", linewidth=2, label=f"Cible ({cible}m)")
        
        # Habillage et métadonnées du graphique
        plt.title(f"Distribution : {label}")
        plt.xlabel(label)
        plt.ylabel("Nombre de détections")
        plt.legend()
        
        # Enregistrement de la figure sur le disque et libération de la mémoire
        plt.savefig(os.path.join(self.output_dir, nom_fichier))
        plt.close()

if __name__ == "__main__":
    # Point d'entrée de l'application : initialisation de l'instance
    analyseur = StairChecker()

    # Extraction des marches "✓" de tes logs (Profondeur, Hauteur) en cm
    # Note : Le tuple correspond à l'association (valeur_profondeur, valeur_hauteur)
    donnees_log = [
        (25.0, 29.9), (27.6, 6.6),   # Frame 71
        (18.8, 28.2), (27.0, 5.3),   # Frame 72
        (24.7, 29.4), (26.6, 5.2),   # Frame 75
        (24.7, 29.4), (27.4, 6.4),   # Frame 76
        (23.1, 28.3), (27.4, 5.5)    # Frame 77
    ]

    # Injection itérative des données de test
    for p, h in donnees_log:
        analyseur.ajouter_mesure(p, h)

    # Lancement du pipeline d'analyse et de génération des fichiers
    analyseur.generer_rapport()